# Roteiro de teste — Marco 5.1

Abra o `.rbxlx` no Roblox Studio e use **Play**, não apenas **Run**: precisamos
do personagem e dos scripts de cliente. Deixe o painel Output/Saída aberto.

## Cidade e acessos

- O jogador nasce na praça; saldo, tutorial, Mapa/M, Bike/B e Carro/V continuam disponíveis.
- No mapa aparecem Delegacia e Prisão, além da estrada além do anel externo.
- Chegue à delegacia pelo acesso à avenida: entre na recepção, veja o interior e
  as celas decorativas. Nenhuma interação deve prender outro jogador.
- Dirija até a prisão afastada e confira estrada, entrada, pátio e área de serviço.
- Confira troncos inclinados, variação entre árvores, galhos e raízes. Raízes e folhagem
  não devem bloquear a passagem do jogador.

## Pena e liberação automática

1. Na recepção da delegacia, aproxime-se da interação **Simular prisão (Studio)** e use E.
2. O personagem deve ir à prisão, a interface mostrar aproximadamente 60 s, e o saldo
   permanecer o mesmo. Se estava trabalhando, a vaga deve ser liberada.
3. Bike/B, Carro/V e entrar em empregos ficam bloqueados durante a detenção.
4. Aguarde o contador chegar a zero: deve haver uma única liberação, no exterior.
5. Confira que andar, usar veículos e pegar emprego voltam a funcionar.

## Rota de fuga

1. Inicie outra simulação na delegacia.
2. Siga a indicação da passagem de manutenção e realize as interações da rota em ordem.
3. Ao concluir a última, a soltura deve acontecer imediatamente, antes dos 60 s.
4. Volte ao último ponto: ele não deve gerar nova soltura nem alterar dinheiro.
5. Tente acionar um ponto adiante sem passar pelo anterior: não deve liberar o jogador.

## Reset e dois jogadores

- Durante a pena, use **Reset Character**: deve reaparecer preso, mantendo o prazo
  original. Ao fim desse prazo, a soltura deve funcionar mesmo após o reset.
- Se estiver sentado quando a pena acaba, o personagem deve ser desocupado e liberado.
- No teste com servidor e dois clientes, só quem iniciou a simulação é detido;
  contadores e progresso da fuga devem ser individuais.
- O estado prisional é temporário: sair do servidor limpa a sessão, sem gravar uma
  pena permanente no DataStore.
- Em uma experiência publicada fora do Studio, o prompt de simulação não deve aparecer.

## Regressão e celular

- Conclua um pedido de pizza, atendimento de mercado e entrega.
- Confira o carro e a bike também fora das instalações novas.
- Use o emulador de celular: confira leitura do mapa, cartão de prisão, botão de pulo,
  botões de veículo e interações por toque.
- Confira NPCs e desempenho ao atravessar a praça e a estrada.

Registre o que passou e o texto completo dos erros no Output. A ausência de um erro
de sintaxe, por si só, não confirma esses comportamentos visuais ou físicos.
