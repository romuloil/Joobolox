# Validação — Marco 5.1

## Executado neste ambiente

- **37 de 37 scripts** compilados com o compilador oficial do Luau 0.698,
  revisão `ff6d381e57bcd1799d850d7fabe543c0f0980a5d`.
- **42 verificações de regras**: prazo, limites, sequência da fuga, distância,
  tempo de percurso e rejeição de valores inválidos.
- **40 verificações do serviço prisional** com relógio, eventos e objetos controlados:
  liberação por prazo, fuga, repetição de ações, reset/respawn, movimento inválido,
  entrada exclusiva do Studio, falha na preparação e preservação do dinheiro.
- **48.402 verificações de geometria** executando os próprios construtores:
  separação da delegacia e lojas, pontos dentro dos limites, espaço para um personagem
  no trajeto de entrada/fuga, árvores e dimensões válidas do terreno.
- O terreno foi dividido em **quatro placas de 1.200 × 1.200 studs**. Os testes
  rejeitam peças acima do limite de 2.048 studs por eixo e verificam a cobertura
  contínua sob a prisão, os pontos de saída e os encontros das placas.
- **237 árvores** no cenário simulado: até 16 peças cada, raízes e copas sem colisão.
- O gerador de `.rbxlx` relê o XML salvo e compara o conteúdo de todos os scripts
  com os arquivos de origem para detectar perda ou alteração na serialização.

## O que esses testes não comprovam

Não há Roblox Studio neste ambiente Linux. Os testes de serviço e geometria usam
objetos simulados; não executam renderização, física, Humanoid, animações, assets
online, rede ou DataStore do Roblox. O gerador aleatório dos testes também é
diferente do gerador interno do Roblox: contagens de residências e posição das
árvores no Studio podem variar.

As verificações geométricas medem espaço livre no desenho das peças, mas não
substituem atravessar os locais com um avatar real. Aparência, jogabilidade,
replicação, salvamento, desempenho e regressão das profissões dependem do roteiro
em [TESTE_NO_STUDIO.md](TESTE_NO_STUDIO.md).

## Reproduzir

```sh
python tools/validate_luau.py --luau-dir /workspace/tooling/luau-0.698/source
python tools/build_rbxlx.py src dist/LittleLife_Marco5_1.rbxlx
```

Em outra máquina, ajuste o caminho do compilador. As instruções de preparação do
Luau oficial estão em [../tools/VALIDACAO.md](../tools/VALIDACAO.md). Para abrir o
jogo no Studio, nenhuma dessas ferramentas é necessária: basta o `.rbxlx` entregue.
