# Validação do código

Os testes usam o compilador e o interpretador oficiais do Luau. Eles verificam
sintaxe, regras de detenção/fuga e decisões do serviço com relógio/eventos
controlados. Não executam o motor Roblox: visual, colisões reais, animações,
replicação e desempenho ainda precisam de teste no Roblox Studio.

No ambiente usado para esta entrega:

```sh
python tools/validate_luau.py --luau-dir /workspace/tooling/luau-0.698/source
```

Para preparar as ferramentas em outra máquina com Git, GNU Make e um compilador
C++17, use o código oficial, preservando TLS e a revisão abaixo:

```sh
git clone --depth 1 --branch 0.698 https://github.com/luau-lang/luau.git luau-tools
git -C luau-tools rev-parse HEAD
# Revisão esperada: ff6d381e57bcd1799d850d7fabe543c0f0980a5d
make -C luau-tools -j2 config=release luau luau-compile
python tools/validate_luau.py --luau-dir /caminho/para/luau-tools
```

Os stubs em `tests/roblox_geometry_mock.luau` implementam apenas o subconjunto de
valores e objetos usado pelos testes. O gerador pseudoaleatório do stub não é o
gerador interno do Roblox; resultados de contagem de lotes não são uma previsão
exata da cena no Studio. A geometria fixa, os pontos da prisão e suas distâncias
podem ser verificados sem renderização.
