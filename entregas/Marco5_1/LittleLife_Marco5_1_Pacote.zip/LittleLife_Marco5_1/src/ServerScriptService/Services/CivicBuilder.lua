-- Delegacia urbana e prisão afastada; geometria sem autoridade de jogo.
-- PrisonService controla os prompts, a pena, a fuga e a entrada de teste no Studio.
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("CivicConfig"))

local CivicBuilder = { sites = nil }
local WHITE = Color3.fromRGB(235, 235, 224)
local BLUE = Color3.fromRGB(31, 69, 107)
local STEEL = Color3.fromRGB(82, 96, 104)
local STONE = Color3.fromRGB(173, 176, 163)
local WOOD = Color3.fromRGB(141, 104, 69)
local AMBER = Color3.fromRGB(235, 174, 70)

local function folder(parent, name)
	local f = Instance.new("Folder")
	f.Name, f.Parent = name, parent
	return f
end

local function part(parent, name, size, cf, color, material, collide)
	local p = Instance.new("Part")
	p.Name, p.Size, p.CFrame = name, size, cf
	p.Anchored = true
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Color, p.Material = color or WHITE, material or Enum.Material.SmoothPlastic
	p.CanCollide = collide ~= false
	p.Parent = parent
	return p
end

local function localPart(parent, base, name, size, position, color, material, collide)
	return part(parent, name, size, base * CFrame.new(position), color, material, collide)
end

local function label(target, text, color, face)
	local gui = Instance.new("SurfaceGui")
	gui.Name = "Letreiro"
	gui.Face = face or Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud, gui.LightInfluence = 35, 0
	gui.Parent = target
	local t = Instance.new("TextLabel")
	t.Size = UDim2.fromScale(1, 1)
	t.BackgroundTransparency = 1
	t.TextColor3 = color or WHITE
	t.TextScaled, t.TextWrapped = true, true
	t.Font, t.Text = Enum.Font.GothamBold, text
	t.Parent = gui
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft, pad.PaddingRight = UDim.new(0, 5), UDim.new(0, 5)
	pad.Parent = t
end

local function sign(parent, base, text, pos, size, color)
	local p = localPart(parent, base, "Placa", size or Vector3.new(16, 3, 0.3), pos, color or BLUE, nil, false)
	label(p, text)
	return p
end

local function lamp(parent, base, pos)
	local lightPart = localPart(parent, base, "Luminária", Vector3.new(4, 0.2, 2), pos, Color3.fromRGB(255, 241, 205), Enum.Material.Neon, false)
	local light = Instance.new("PointLight")
	light.Brightness, light.Range, light.Shadows = 1.15, 23, false
	light.Color, light.Parent = lightPart.Color, lightPart
end

local function bench(parent, base, pos, color)
	local p = Instance.new("Seat")
	p.Name, p.Size, p.CFrame = "Banco", Vector3.new(7, 0.5, 2), base * CFrame.new(pos)
	p.Anchored, p.CanTouch = true, false
	p.Color, p.Material = color or WOOD, Enum.Material.SmoothPlastic
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = parent
	for _, x in ipairs({ -2.6, 2.6 }) do
		part(parent, "PéBanco", Vector3.new(0.5, 1.7, 1.6), p.CFrame * CFrame.new(x, -1, 0), STEEL)
	end
	part(parent, "Encosto", Vector3.new(7, 1.9, 0.3), p.CFrame * CFrame.new(0, 0.9, 0.9), color or WOOD)
	-- SeatService acrescenta o prompt E sem sentar automaticamente ao encostar.
end

local function plant(parent, base, pos)
	localPart(parent, base, "Floreira", Vector3.new(5, 1.8, 3), pos + Vector3.new(0, 0.9, 0), STONE, Enum.Material.Concrete)
	local foliage = localPart(parent, base, "Arbusto", Vector3.new(4.7, 2.6, 2.8), pos + Vector3.new(0, 2.3, 0), Color3.fromRGB(77, 125, 71), Enum.Material.Grass, false)
	foliage.Shape = Enum.PartType.Ball
end

local function marker(parent, base, name, position)
	local p = localPart(parent, base, name, Vector3.new(1, 1, 1), position, WHITE, nil, false)
	p.Transparency, p.CanTouch, p.CanQuery = 1, false, false
	return p
end

local function newSite(parent, name, mapLabel, kind, base)
	local m = Instance.new("Model")
	m.Name = name
	m:SetAttribute("PlaceName", name)
	m:SetAttribute("MapLabel", mapLabel)
	m:SetAttribute("Kind", kind)
	m:SetAttribute("MapPosition", base.Position)
	m.Parent = parent
	return m
end

local function point(parent, base, name, pos, action, object, hold)
	local p = localPart(parent, base, name, Vector3.new(2.5, 2.5, 0.5), pos, AMBER, Enum.Material.Metal, false)
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = name .. "Prompt"
	prompt.ActionText, prompt.ObjectText = action, object
	prompt.KeyboardKeyCode = Enum.KeyCode.E
	prompt.HoldDuration, prompt.MaxActivationDistance = hold or 1, 9
	prompt.RequiresLineOfSight, prompt.Enabled = true, false
	prompt.Parent = p
	return prompt
end

local function street(parent, road)
	local length = (road.b - road.a).Magnitude
	local cf = CFrame.lookAt((road.a + road.b) / 2, road.b)
	local p = part(parent, road.name, Vector3.new(road.width, 0.5, length), cf * CFrame.new(0, 0.25, 0), Color3.fromRGB(67, 70, 73), Enum.Material.Asphalt)
	p:SetAttribute("RoadStart", road.a)
	p:SetAttribute("RoadEnd", road.b)
	for _, side in ipairs({ -1, 1 }) do
		part(parent, "Calçada", Vector3.new(3, 0.6, length), cf * CFrame.new(side * (road.width / 2 + 1.5), 0.4, 0), STONE, Enum.Material.Concrete)
	end
	if road.width > 15 then
		for z = -length / 2 + 7, length / 2 - 4, 16 do
			part(parent, "Faixa", Vector3.new(0.25, 0.03, 7), cf * CFrame.new(0, 0.52, z), AMBER, nil, false)
		end
		for z = -length / 2 + 20, length / 2 - 10, 65 do
			local poleCf = cf * CFrame.new(road.width / 2 + 3, 0, z)
			localPart(parent, poleCf, "Poste", Vector3.new(0.5, 11, 0.5), Vector3.new(0, 5.5, 0), STEEL, Enum.Material.Metal)
			lamp(parent, poleCf, Vector3.new(-1, 11, 0))
		end
	end
end

local function station(parent)
	local base = Config.Station.CFrame
	local m = newSite(parent, Config.Station.Name, "Delegacia", "Police", base)
	local function p(name, size, pos, color, material, collide)
		return localPart(m, base, name, size, pos, color, material, collide)
	end
	p("Pátio", Vector3.new(52, 0.8, 72), Vector3.new(0, 0.4, 0), STONE, Enum.Material.Concrete)
	p("Piso", Vector3.new(44, 0.3, 54), Vector3.new(0, 0.95, 0), WHITE, Enum.Material.Marble)
	p("ParedeFundos", Vector3.new(44, 16, 1), Vector3.new(0, 8.8, 26.5))
	for _, x in ipairs({ -21.5, 21.5 }) do
		p("ParedeLateral", Vector3.new(1, 16, 54), Vector3.new(x, 8.8, 0))
		p("FaixaAzul", Vector3.new(1.05, 2.3, 53), Vector3.new(x, 12, 0), BLUE)
	end
	for _, side in ipairs({ -1, 1 }) do
		p("Fachada", Vector3.new(18, 16, 1), Vector3.new(side * 13, 8.8, -26.5))
		local glass = p("Janela", Vector3.new(9, 5, 0.2), Vector3.new(side * 13, 6, -27.1), Color3.fromRGB(142, 185, 202), Enum.Material.Glass)
		glass.Transparency = 0.15
		p("Pórtico", Vector3.new(1, 10, 1), Vector3.new(side * 4.5, 5.8, -27.5), BLUE)
	end
	p("VigaPorta", Vector3.new(8, 6, 1), Vector3.new(0, 13.8, -26.5), BLUE)
	p("Cobertura", Vector3.new(46, 0.8, 56), Vector3.new(0, 17.2, 0), BLUE)
	p("Marquise", Vector3.new(14, 0.5, 6), Vector3.new(0, 10.6, -29), BLUE, nil, false)
	sign(m, base, "CENTRO POLICIAL\nLITTLE LITTLE KINDER", Vector3.new(0, 14, -27.1), Vector3.new(35, 4, 0.35))
	p("BalcãoRecepção", Vector3.new(18, 3.5, 3), Vector3.new(-5, 2.7, -5), WOOD)
	p("Tampo", Vector3.new(19, 0.3, 3.6), Vector3.new(-5, 4.6, -5), BLUE)
	sign(m, base, "RECEPÇÃO", Vector3.new(-5, 3.1, -6.8), Vector3.new(9, 1.5, 0.2))
	p("Monitor", Vector3.new(3, 2, 0.3), Vector3.new(-4, 5.75, -4.8), STEEL)
	bench(m, base, Vector3.new(12, 2.4, -15), BLUE)
	plant(m, base, Vector3.new(-18, 1.1, -20))
	-- Sala de apoio à esquerda; passagem de 8 studs na divisória.
	p("DivisóriaApoio", Vector3.new(1, 10, 19), Vector3.new(-1, 5.8, 16))
	sign(m, base, "APOIO À PATRULHA", Vector3.new(-11, 9, 25.8), Vector3.new(17, 2, 0.2))
	p("MesaApoio", Vector3.new(12, 2.8, 6), Vector3.new(-11, 2.5, 15), WOOD)
	p("MapaDePatrulha", Vector3.new(12, 7, 0.3), Vector3.new(-11, 8.6, 25.8), Color3.fromRGB(94, 129, 109), nil, false)
	for i = 1, 4 do
		p("Armário", Vector3.new(2.7, 7, 2.5), Vector3.new(-18 + i * 3, 4.5, 22.5), BLUE)
	end
	-- Cela decorativa: não participa da pena, que acontece na prisão afastada.
	for x = 3, 20, 2 do
		p("GradeDecorativa", Vector3.new(0.3, 9, 0.3), Vector3.new(x, 5.4, 9), STEEL, Enum.Material.Metal)
	end
	p("TravessaGrade", Vector3.new(18, 0.4, 0.4), Vector3.new(12, 9.8, 9), STEEL)
	bench(m, base, Vector3.new(12, 2.4, 21), STONE)
	sign(m, base, "CELA DE APOIO\nÁrea cenográfica", Vector3.new(12, 11.5, 8.9), Vector3.new(17, 2.5, 0.2))
	for _, x in ipairs({ -11, 11 }) do
		for _, z in ipairs({ -15, 14 }) do lamp(m, base, Vector3.new(x, 16.5, z)) end
	end
	-- Duas vagas pintadas no recuo, sem veículos autônomos ou bloqueio da entrada.
	for _, x in ipairs({ -17, 17 }) do
		for _, side in ipairs({ -1, 1 }) do p("Vaga", Vector3.new(0.15, 0.05, 7), Vector3.new(x + side * 3.7, 0.84, -31), WHITE, nil, false) end
	end
	local intake = point(m, base, "SimulaçãoStudio", Vector3.new(-10, 5.2, -8), "Simular prisão (Studio)", "Teste de 60 segundos", 1)
	return intake
end

local function prison(parent)
	local base = Config.Prison.CFrame
	local m = newSite(parent, Config.Prison.Name, "Prisão", "Prison", base)
	local function p(name, size, pos, color, material, collide)
		return localPart(m, base, name, size, pos, color, material, collide)
	end
	p("Terreno", Vector3.new(178, 0.8, 164), Vector3.new(0, 0.4, 0), Color3.fromRGB(148, 154, 135), Enum.Material.Concrete)
	-- Perímetro alto, com abertura exclusiva para a passagem de manutenção.
	p("MuroEsquerdo", Vector3.new(2, 20, 150), Vector3.new(-80, 10.8, 0), STONE, Enum.Material.Concrete)
	p("MuroFundos", Vector3.new(160, 20, 2), Vector3.new(0, 10.8, 75), STONE, Enum.Material.Concrete)
	p("MuroDireitoFrente", Vector3.new(2, 20, 26), Vector3.new(80, 10.8, -62), STONE, Enum.Material.Concrete)
	p("MuroDireitoFundos", Vector3.new(2, 20, 110), Vector3.new(80, 10.8, 20), STONE, Enum.Material.Concrete)
	p("VergaManutenção", Vector3.new(2, 11, 14), Vector3.new(80, 15.3, -42), STONE, Enum.Material.Concrete)
	for _, side in ipairs({ -1, 1 }) do
		p("MuroFrente", Vector3.new(68, 20, 2), Vector3.new(side * 46, 10.8, -75), STONE, Enum.Material.Concrete)
	end
	p("PortãoSeguro", Vector3.new(24, 12, 0.8), Vector3.new(0, 6.8, -75), BLUE, Enum.Material.Metal)
	sign(m, base, "CENTRO DE REINTEGRAÇÃO KINDER", Vector3.new(0, 17, -76.2), Vector3.new(65, 4, 0.5))
	-- Recepção pública fora do perímetro, acessível pela estrada.
	p("PátioVisitas", Vector3.new(74, 0.8, 42), Vector3.new(0, 0.4, -100), STONE, Enum.Material.Concrete)
	p("RecepçãoFundos", Vector3.new(56, 12, 1), Vector3.new(0, 6.8, -80))
	for _, x in ipairs({ -27.5, 27.5 }) do p("RecepçãoLateral", Vector3.new(1, 12, 24), Vector3.new(x, 6.8, -92)) end
	for _, side in ipairs({ -1, 1 }) do p("RecepçãoFrente", Vector3.new(22, 12, 1), Vector3.new(side * 17, 6.8, -104)) end
	p("RecepçãoVerga", Vector3.new(12, 3, 1), Vector3.new(0, 11.3, -104))
	p("RecepçãoTeto", Vector3.new(58, 0.6, 26), Vector3.new(0, 13.1, -92), BLUE)
	p("BalcãoVisitas", Vector3.new(20, 3.5, 3), Vector3.new(0, 2.6, -84), WOOD)
	sign(m, base, "VISITAS E INFORMAÇÕES\nDetenção: 60 segundos", Vector3.new(0, 7, -80.7), Vector3.new(30, 4, 0.2))
	lamp(m, base, Vector3.new(0, 12.6, -94))
	plant(m, base, Vector3.new(-32, 0.8, -107))
	plant(m, base, Vector3.new(32, 0.8, -107))
	-- Bloco de celas aberto para o pátio interno: portas largas, sem colisão invisível.
	p("BlocoPiso", Vector3.new(64, 0.3, 70), Vector3.new(-36, 0.95, -22), WHITE)
	p("BlocoFundos", Vector3.new(64, 16, 1), Vector3.new(-36, 8.8, 13), WHITE)
	for _, x in ipairs({ -68, -4 }) do p("BlocoLateral", Vector3.new(1, 16, 70), Vector3.new(x, 8.8, -22), WHITE) end
	for _, side in ipairs({ -1, 1 }) do p("BlocoFrente", Vector3.new(25, 16, 1), Vector3.new(-36 + side * 19.5, 8.8, -57), WHITE) end
	p("BlocoVerga", Vector3.new(14, 6, 1), Vector3.new(-36, 13.8, -57), WHITE)
	p("BlocoTeto", Vector3.new(66, 0.6, 72), Vector3.new(-36, 17.1, -22), BLUE)
	sign(m, base, "ALOJAMENTOS 01 — 03", Vector3.new(-36, 13.8, -57.7), Vector3.new(34, 3, 0.2))
	for i = 0, 2 do
		local z = -43 + i * 20
		p("Cama", Vector3.new(5, 1.2, 9), Vector3.new(-58, 1.8, z), STEEL, Enum.Material.Metal)
		p("Colchão", Vector3.new(4.8, 0.6, 8.8), Vector3.new(-58, 2.7, z), Color3.fromRGB(90, 134, 162), Enum.Material.Fabric)
		p("Travesseiro", Vector3.new(4.1, 0.45, 2), Vector3.new(-58, 3.2, z + 2.8), WHITE, Enum.Material.Fabric, false)
		if i < 2 then p("DivisóriaCela", Vector3.new(18, 10, 0.5), Vector3.new(-58, 5.8, z + 10), STONE) end
		-- Grades laterais deixam corredor central contínuo, em vez de fechar o preso.
		for zz = z - 8, z - 2, 2 do p("GradeCela", Vector3.new(0.25, 9, 0.25), Vector3.new(-49, 5.4, zz), STEEL, Enum.Material.Metal) end
	end
	for _, z in ipairs({ -41, -8 }) do lamp(m, base, Vector3.new(-35, 16.6, z)) end
	sign(m, base, "PÁTIO →\nSaída pela porta central", Vector3.new(-36, 7, 12.4), Vector3.new(24, 3, 0.2))
	bench(m, base, Vector3.new(18, 2.4, 18))
	bench(m, base, Vector3.new(44, 2.4, 18))
	p("Quadra", Vector3.new(48, 0.04, 34), Vector3.new(35, 0.83, 42), Color3.fromRGB(116, 137, 117), Enum.Material.Concrete, false)
	for _, x in ipairs({ 11, 59 }) do p("LinhaQuadra", Vector3.new(0.18, 0.06, 34), Vector3.new(x, 0.88, 42), WHITE, nil, false) end
	for _, z in ipairs({ 25, 59 }) do p("LinhaQuadra", Vector3.new(48, 0.06, 0.18), Vector3.new(35, 0.88, z), WHITE, nil, false) end
	sign(m, base, "MANUTENÇÃO →\nRota de fuga", Vector3.new(31, 5, -58), Vector3.new(21, 3, 0.3), AMBER)
	-- Passagem reta acima do solo: não exige agachar nem depende de Terrain.
	p("PassagemPiso", Vector3.new(96, 0.8, 12), Vector3.new(86, 0.4, -42), STONE, Enum.Material.Concrete)
	for _, z in ipairs({ -48, -36 }) do p("PassagemLateral", Vector3.new(96, 8, 0.7), Vector3.new(86, 4.8, z), STONE, Enum.Material.Concrete) end
	p("PassagemTeto", Vector3.new(96, 0.5, 13), Vector3.new(86, 9, -42), STEEL, Enum.Material.Metal)
	for _, x in ipairs({ 55, 86, 115 }) do lamp(m, base, Vector3.new(x, 8.6, -42)) end
	local steps = {
		point(m, base, "EscapeHatch", Vector3.new(45, 3.2, -42), "Abrir acesso", "1/3 • Manutenção", 2),
		point(m, base, "EscapePassage", Vector3.new(102, 3.2, -42), "Atravessar passagem", "2/3 • Passagem", 1),
		point(m, base, "EscapeExit", Vector3.new(134, 3.2, -42), "Concluir fuga", "3/3 • Área externa", 1),
	}
	-- Prompts nas laterais, sem obstáculo na passagem de 11 studs.
	for _, prompt in ipairs(steps) do
		prompt.Parent.CFrame = prompt.Parent.CFrame * CFrame.new(0, 0, -4.8)
	end
	-- Área de serviço próxima da saída da fuga, ligada ao acesso principal.
	local fuelBase = base * CFrame.new(145, 0, 15)
	local fuel = newSite(parent, "Parada da Serra", "Posto / Conveniência", "Fuel", fuelBase)
	localPart(fuel, fuelBase, "PátioPosto", Vector3.new(52, 0.8, 55), Vector3.new(0, 0.4, 0), STONE, Enum.Material.Concrete)
	localPart(fuel, fuelBase, "Conveniência", Vector3.new(38, 11, 16), Vector3.new(0, 6.3, 17), WHITE)
	sign(fuel, fuelBase, "PARADA DA SERRA\nCONVENIÊNCIA", Vector3.new(0, 10, 8.7), Vector3.new(34, 3, 0.4), Color3.fromRGB(70, 125, 88))
	for _, x in ipairs({ -11, 11 }) do
		localPart(fuel, fuelBase, "BombaCenográfica", Vector3.new(3, 4.5, 2), Vector3.new(x, 3.1, -4), BLUE)
		localPart(fuel, fuelBase, "VisorBomba", Vector3.new(2.4, 1.4, 0.2), Vector3.new(x, 4.1, -5.1), STEEL, nil, false)
	end
	localPart(fuel, fuelBase, "CoberturaPosto", Vector3.new(42, 0.7, 24), Vector3.new(0, 12, -4), Color3.fromRGB(70, 125, 88))
	for _, x in ipairs({ -18, 18 }) do localPart(fuel, fuelBase, "PilarPosto", Vector3.new(0.6, 11, 0.6), Vector3.new(x, 6.3, -8), STEEL) end
	-- Trilho de fuga leva ao posto; o retorno usa o acesso público da frente.
	p("CaminhoPosto", Vector3.new(10, 0.4, 67), Vector3.new(140, 0.4, -12), STONE, Enum.Material.Concrete)
	p("AcessoPosto", Vector3.new(14, 0.5, 134), Vector3.new(180, 0.25, -47), Color3.fromRGB(67, 70, 73), Enum.Material.Asphalt)
	p("RetornoCidade", Vector3.new(180, 0.5, 14), Vector3.new(90, 0.25, -114), Color3.fromRGB(67, 70, 73), Enum.Material.Asphalt)
	return {
		prisonSpawn = marker(m, base, "PrisonSpawn", Vector3.new(-46, 4, -20)),
		prisonRelease = marker(m, base, "PrisonRelease", Vector3.new(0, 4, -113)),
		escapeSteps = steps,
		prisonBounds = { cf = base * CFrame.new(Config.Prison.BoundsCenter), half = Config.Prison.BoundsHalf },
	}
end

function CivicBuilder.build(map)
	if CivicBuilder.sites then return CivicBuilder.sites end
	-- Recupera referências de mapas já presentes ao reexecutar a inicialização.
	local existing = map:FindFirstChild("CivicLocations")
	if existing and map:GetAttribute("CivicReady") then
		local prisonModel = existing:FindFirstChild(Config.Prison.Name)
		local stationModel = existing:FindFirstChild(Config.Station.Name)
		if prisonModel and stationModel then
			local steps = {}
			for _, name in ipairs({ "EscapeHatch", "EscapePassage", "EscapeExit" }) do
				local target = prisonModel:FindFirstChild(name)
				table.insert(steps, target and target:FindFirstChildOfClass("ProximityPrompt"))
			end
			local intake = stationModel:FindFirstChild("SimulaçãoStudio")
			CivicBuilder.sites = {
				prisonSpawn = prisonModel:FindFirstChild("PrisonSpawn"),
				prisonRelease = prisonModel:FindFirstChild("PrisonRelease"),
				intakePrompt = intake and intake:FindFirstChildOfClass("ProximityPrompt"),
				escapeSteps = steps,
				prisonBounds = { cf = Config.Prison.CFrame * CFrame.new(Config.Prison.BoundsCenter), half = Config.Prison.BoundsHalf },
			}
			return CivicBuilder.sites
		end
	end
	assert(not existing, "CivicLocations parcial já existe; restaure a versão completa antes de reconstruir.")
	local locations = folder(map, "CivicLocations")
	local roads = folder(map, "CivicRoads")
	for _, road in ipairs(Config.Roads) do street(roads, road) end
	CivicBuilder.sites = prison(locations)
	CivicBuilder.sites.intakePrompt = station(locations)
	map:SetAttribute("CivicReady", true)
	return CivicBuilder.sites
end

return CivicBuilder
