-- Prisão autoritativa de 60 segundos, com saída pelo tempo ou rota fixa de fuga.
-- Não recebe comandos remotos de detenção. Uma futura PoliceService deve validar
-- papel, evento, imobilização e proximidade ANTES de chamar detain no servidor.
-- Esta etapa não altera dinheiro nem inventa recompensas de assalto.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local GameConfig = require(Shared:WaitForChild("GameConfig"))
local CivicConfig = require(Shared:WaitForChild("CivicConfig"))
local Rules = require(Shared:WaitForChild("PrisonRules"))
local SecurityService = require(script.Parent:WaitForChild("SecurityService"))

local PrisonService = {}
local sessions = {}
local initialized = false
local sites, hooks, uiUpdate
local WALK_SPEED = GameConfig.WalkSpeed

local function now()
	return Workspace:GetServerTimeNow()
end

local function promptPosition(prompt)
	local parent = prompt and prompt.Parent
	if parent and parent:IsA("BasePart") then
		return parent.Position
	elseif parent and parent:IsA("Attachment") then
		return parent.WorldPosition
	end
	return nil
end

local function nextHint(session)
	local prompt = sites.escapeSteps[session.completed + 1]
	if prompt and prompt.ObjectText ~= "" then
		return prompt.ObjectText
	end
	return "Siga a passagem de manutenção para tentar fugir."
end

local function sendState(player, session, customHint)
	local hint = customHint or nextHint(session)
	player:SetAttribute("Detained", true)
	player:SetAttribute("PrisonEndsAt", session.endsAt)
	player:SetAttribute("PrisonStep", session.completed)
	player:SetAttribute("PrisonSteps", #sites.escapeSteps)
	player:SetAttribute("PrisonHint", hint)
	uiUpdate:FireClient(player, "PrisonState", {
		active = true,
		endsAt = session.endsAt,
		step = session.completed,
		steps = #sites.escapeSteps,
		hint = hint,
	})
end

local function clearAttributes(player)
	player:SetAttribute("Detained", false)
	player:SetAttribute("PrisonEndsAt", nil)
	player:SetAttribute("PrisonStep", nil)
	player:SetAttribute("PrisonSteps", nil)
	player:SetAttribute("PrisonHint", nil)
end

local function moveCharacter(character, humanoid, root, target)
	-- Sit=false pode deixar SeatWeld vivo até o próximo passo de física. Solta
	-- apenas a junta deste personagem antes de mover, sem arrastar banco/carro.
	local seat = humanoid.SeatPart
	local seatWeld = seat and seat:FindFirstChild("SeatWeld")
	if seatWeld and seatWeld:IsA("Weld") then
		local p0, p1 = seatWeld.Part0, seatWeld.Part1
		if (p0 and p0:IsDescendantOf(character)) or (p1 and p1:IsDescendantOf(character)) then
			seatWeld:Destroy()
		end
	end
	humanoid.Sit = false
	root.AssemblyLinearVelocity = Vector3.zero
	root.AssemblyAngularVelocity = Vector3.zero
	character:PivotTo(target.CFrame)
end

local function placeInPrison(player, session)
	local character, humanoid, root = SecurityService.getLivingCharacter(player)
	if not character then
		return
	end
	if session.humanoid ~= humanoid then
		session.humanoid = humanoid
		session.previousWalkSpeed = humanoid.WalkSpeed
	end
	humanoid.WalkSpeed = WALK_SPEED
	moveCharacter(character, humanoid, root, sites.prisonSpawn)
	session.completed = 0
	session.lastStepAt = now()
	session.lastStepPosition = root.Position
	session.lastMotionAt = session.lastStepAt
	session.lastMotionPosition = root.Position
	sendState(player, session)
end

function PrisonService.isDetained(player)
	return sessions[player] ~= nil
end

function PrisonService.release(player, escaped)
	escaped = escaped == true
	local session = sessions[player]
	if not session then
		return false
	end
	-- Retira primeiro: timeout e último prompt no mesmo frame só resolvem uma vez.
	sessions[player] = nil
	clearAttributes(player)
	local character, humanoid, root = SecurityService.getLivingCharacter(player)
	if humanoid then
		if session.humanoid == humanoid and Rules.isFinite(session.previousWalkSpeed) then
			humanoid.WalkSpeed = session.previousWalkSpeed
		else
			humanoid.WalkSpeed = WALK_SPEED
		end
		if not escaped then
			moveCharacter(character, humanoid, root, sites.prisonRelease)
		end
	end
	if player.Parent == Players then
		uiUpdate:FireClient(player, "PrisonState", { active = false, escaped = escaped == true })
		uiUpdate:FireClient(player, "Notice", {
			text = escaped and "Você concluiu a rota de fuga e está livre!"
				or "Tempo cumprido. Você está livre!",
		})
	end
	return true
end

function PrisonService.detain(player, reason)
	if not initialized or player.Parent ~= Players then
		return false, "unavailable"
	end
	if sessions[player] then
		return false, "already_detained"
	end
	local character = SecurityService.getLivingCharacter(player)
	if not character then
		return false, "character"
	end
	local deadline = Rules.deadline(now(), CivicConfig.SentenceSeconds or 60)
	if not deadline then
		return false, "duration"
	end
	local session = { endsAt = deadline, completed = 0, reason = reason }
	sessions[player] = session
	-- Bloqueia novas ações antes de remover o veículo e encerrar a profissão.
	player:SetAttribute("Detained", true)
	if hooks.beforeDetain then
		local ok, err = pcall(hooks.beforeDetain, player)
		if not ok then
			sessions[player] = nil
			clearAttributes(player)
			warn("[PrisonService] Falha ao preparar detenção: " .. tostring(err))
			return false, "prepare"
		end
	end
	if sessions[player] ~= session or player.Parent ~= Players then
		return false, "cancelled"
	end
	placeInPrison(player, session)
	return true
end

local function positionAllowed(root, session, time)
	local position = root.Position
	if not Rules.isFinitePoint(position) then
		return false
	end
	local localPosition = sites.prisonBounds.cf:PointToObjectSpace(position)
	local half = sites.prisonBounds.half
	if math.abs(localPosition.X) > half.X or math.abs(localPosition.Y) > half.Y
		or math.abs(localPosition.Z) > half.Z then
		return false
	end
	return not session.lastMotionPosition or Rules.movementAllowed(
		(position - session.lastMotionPosition).Magnitude, time - session.lastMotionAt, WALK_SPEED)
end

local function tryStep(player, index, prompt)
	local session = sessions[player]
	if not session or not SecurityService.checkRate(player, "PrisonStep", 0.35) then
		return
	end
	local time = now()
	if Rules.remaining(session.endsAt, time) <= 0 then
		PrisonService.release(player, false)
		return
	end
	local _, _, root = SecurityService.getLivingCharacter(player)
	local target = promptPosition(prompt)
	if not root or not Rules.isFinitePoint(root.Position) or not Rules.isFinitePoint(target)
		or not session.lastStepPosition then
		return
	end
	-- Verifica também no próprio evento: um teleporte seguido de Triggered não
	-- pode aproveitar a janela entre duas amostras do monitor periódico.
	if not positionAllowed(root, session, time) then
		placeInPrison(player, session)
		return
	end
	local allowed = Rules.canAdvance(session.completed + 1, index,
		(root.Position - target).Magnitude, time - session.lastStepAt,
		(session.lastStepPosition - target).Magnitude, WALK_SPEED, true)
	if not allowed then
		return
	end
	session.completed = index
	session.lastStepAt = time
	session.lastStepPosition = root.Position
	if index == #sites.escapeSteps then
		PrisonService.release(player, true)
	else
		sendState(player, session)
	end
end

local function watchPlayer(player)
	player.CharacterAdded:Connect(function(character)
		-- Pena e prazo pertencem ao Player: resetar o personagem não libera o preso.
		task.spawn(function()
			local humanoid = character:WaitForChild("Humanoid", 10)
			local root = character:WaitForChild("HumanoidRootPart", 10)
			local session = sessions[player]
			if not humanoid or not root or not session or player.Character ~= character then
				return
			end
			if Rules.remaining(session.endsAt, now()) <= 0 then
				PrisonService.release(player, false)
			else
				placeInPrison(player, session)
			end
		end)
	end)
end

local function updateSession(player, session, time)
	if Rules.remaining(session.endsAt, time) <= 0 then
		PrisonService.release(player, false)
		return
	end
	local _, humanoid, root = SecurityService.getLivingCharacter(player)
	if not root then
		session.lastMotionPosition = nil
		return
	end
	humanoid.WalkSpeed = WALK_SPEED
	if not positionAllowed(root, session, time) then
		-- Recomeça só a rota, nunca reinicia nem acrescenta tempo à pena original.
		placeInPrison(player, session)
		return
	end
	session.lastMotionPosition = root.Position
	session.lastMotionAt = time
end

function PrisonService.init(remotes, civicSites, options)
	if initialized then
		return
	end
	assert(civicSites and civicSites.prisonSpawn and civicSites.prisonRelease
		and civicSites.intakePrompt and civicSites.prisonBounds
		and #civicSites.escapeSteps > 0, "[PrisonService] Pontos da prisão incompletos")
	sites = civicSites
	hooks = options or {}
	uiUpdate = assert(remotes[GameConfig.Remotes.UIUpdate], "UIUpdate ausente")
	initialized = true
	for index, prompt in ipairs(sites.escapeSteps) do
		prompt.Enabled = true -- o construtor entrega prompts desligados até os serviços estarem prontos
		prompt.Triggered:Connect(function(player)
			tryStep(player, index, prompt)
		end)
	end
	-- Entrada voluntária de validação; não existe como ferramenta de prisão no jogo publicado.
	sites.intakePrompt.Enabled = RunService:IsStudio()
	sites.intakePrompt.Triggered:Connect(function(player)
		if not RunService:IsStudio() or not SecurityService.checkRate(player, "PrisonIntake", 1) then
			return
		end
		local _, _, root = SecurityService.getLivingCharacter(player)
		local position = promptPosition(sites.intakePrompt)
		if root and position and Rules.isFinitePoint(root.Position)
			and (root.Position - position).Magnitude <= 10 then
			PrisonService.detain(player, "studio_test")
		end
	end)
	Players.PlayerAdded:Connect(watchPlayer)
	for _, player in ipairs(Players:GetPlayers()) do
		watchPlayer(player)
	end
	Players.PlayerRemoving:Connect(function(player)
		sessions[player] = nil -- prisão é estado da sessão, não é gravada no DataStore
	end)
	task.spawn(function()
		while true do
			local time = now()
			for player, session in pairs(sessions) do
				updateSession(player, session, time)
			end
			task.wait(0.2)
		end
	end)
end

return PrisonService
