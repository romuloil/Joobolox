# Little Life: Minha Cidade — Marco 5.1

Continuação do `LittleLife_Marco5.rbxlx`, com delegacia urbana, prisão afastada,
detenção de 60 segundos, fuga por manutenção e árvores de desenho mais orgânico.

## Abrir no computador

1. Extraia o pacote e abra `LittleLife_Marco5_1.rbxlx` no Roblox Studio,
   em **Arquivo → Abrir do arquivo**. Não é necessário instalar plugins.
2. Abra **Output / Saída** e inicie **Play / Jogar (F5)**. O mapa é construído ao iniciar;
   o cenário vazio antes do Play é esperado.
3. Use **M** para localizar **Delegacia** e **Prisão**. **V** chama o carro, **B** a bike,
   e **E** interage. No celular, use os botões da interface e os prompts de proximidade.
4. A delegacia fica na área urbana, próxima da avenida que sai ao norte da praça.
   A prisão fica além do anel externo, ligada à mesma avenida por uma estrada.
5. Na recepção da delegacia, a interação **Simular prisão (Studio)** permite experimentar
   a pena e a rota de fuga. Essa interação só é habilitada pelo servidor no Studio.

Veja o roteiro completo em [docs/TESTE_NO_STUDIO.md](docs/TESTE_NO_STUDIO.md).

## O que este marco implementa

- Delegacia com interior acessível e celas decorativas, separada da prisão ativa.
- Prisão com circulação interna, pátio e rota de fuga fixa, além de área de serviço na saída.
- Pena de 60 segundos controlada pelo servidor; fuga concluída libera imediatamente.
- Interface com tempo restante e indicação da próxima interação.
- Morte/reset não removem a detenção nem reiniciam o prazo. Desconexão encerra o estado
  de sessão, conforme a documentação original.
- Bloqueio de bike, carro e novos empregos durante a detenção; o emprego e o veículo
  anteriores são encerrados ao entrar.
- Árvores com troncos inclinados, galhos, copas assimétricas e raízes aparentes sem colisão.
- Edifícios e estrada novos no mapa da interface.

O sistema completo de assaltos, profissões policiais/ladrão, lançador de água, algemas,
viaturas funcionais e recompensas continua sendo uma etapa futura. Esta versão não
implementa captura de outros jogadores. `PrisonService.detain` é uma API interna do
servidor; o futuro serviço policial deverá validar profissão, suspeito imobilizado,
distância e contexto de crime antes de chamá-la. Não há comando remoto de prisão.

O saldo anterior não é descontado na simulação. Nenhuma regra de recompensa de assalto
foi inventada: a documentação exige uma definição adicional sobre perda na captura e
preservação na fuga, e o Marco 5 ainda não tem eventos de assalto.

## Desenvolver e gerar outra versão

Os scripts estão em `src/`, seguindo os caminhos do Roblox. Preserve `.server.lua`
para Scripts, `.client.lua` para LocalScripts e `.lua` para ModuleScripts.

```sh
cd /workspace/Joobolox
python3 tools/build_rbxlx.py src dist/LittleLife_Marco5_1.rbxlx
```

No computador, abra um terminal na pasta extraída e execute o mesmo comando sem a
linha `cd /workspace/Joobolox`. O gerador só precisa de Python 3; não baixa dependências.

Os cenários, móveis, árvores e veículos são montados por scripts; o `.rbxlx` inclui
esses scripts, não um mapa estático editável antes do Play. Guarde uma cópia do jogo
publicado antes de importar qualquer versão. Para testar DataStore, use uma experiência
de testes publicada e habilite o acesso do Studio aos serviços de API nas configurações
de segurança. Sem isso, o jogo usa dados padrão e avisa que não vai salvar a sessão.

## Validação

Consulte [docs/VALIDACAO.md](docs/VALIDACAO.md) para os resultados e limites dos testes
executados. O Roblox Studio não está disponível no ambiente Linux usado na implementação:
aparência, dirigibilidade, animações e desempenho real precisam do teste no Studio.
